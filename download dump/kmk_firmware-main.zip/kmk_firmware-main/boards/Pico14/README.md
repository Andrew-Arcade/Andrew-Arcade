# Pico 14 Numerical Keypad

![Pico14](https://www.boltind.com/wp-content/uploads/2022/01/PXL_20220119_171113903-scaled.jpg)

Pico 14 Numerical Keypad / Macro Pad PCBs and Hardware Kit.

`kb.py` is designed to work with the Pi Pico.
